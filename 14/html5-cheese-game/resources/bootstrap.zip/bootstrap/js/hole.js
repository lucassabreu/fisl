var Hole = function (x, y, type) {

};

Hole.prototype.draw = function (context) {

};
