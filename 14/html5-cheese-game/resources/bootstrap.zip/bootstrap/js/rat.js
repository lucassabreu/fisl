var Rat = function (interval, probability) {

};


Rat.prototype.draw = function (context) {

};

Rat.prototype.update = function (delta) {

};

Rat.prototype.show = function (hole) {

};
