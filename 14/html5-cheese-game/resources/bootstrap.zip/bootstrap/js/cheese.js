var Cheese = function (x, y) {

};

Cheese.prototype.loadLevel = function (level) {

};

Cheese.prototype.processInputs = function (clicks) {

};

Cheese.prototype.update = function (delta) {

};

Cheese.prototype.draw = function (context) {

};
